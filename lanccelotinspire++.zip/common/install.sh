if $TWEAK; then
     ui_print "      ╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱
     ui_print "    
     ui_print "  L⃣   a⃣   n⃣   c⃣   c⃣   e⃣   l⃣   o⃣   t⃣
     ui_print "   
     ui_print "     ╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱
     ui_print "    
     ui_print ""
     ui_print "☆✭✮ Device: $(getprop ro.product.system.model) ☆✭✮"
     ui_print "☆✭✮ Android: $(getprop ro.system.build.version.release) ☆✭✮"
     ui_print ""
     mv -f $MODPATH/common/lanccelot $MODPATH/lanccelot
else 
     ui_print ""
     abort "☆✭✮ Invalid tweak argument $user! Aborting! ☆✭✮";
fi;
