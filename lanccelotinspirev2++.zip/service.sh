#!/system/bin/sh
if [ "$(grep "# Set-Up lanccelot" $MODPATH/lanccelot)" ]; then
     akirasupr=$(find /data/adb/modules -name lanccelot)
     rm -rf $akirasupr
else 
     am kill-all
     am force-stop all
     $MODDIR/lanccelot
fi;
